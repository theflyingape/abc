README.txt
----------
fcbpaint V0.6 by Daniel Kahlin (aka tlr), 2013-10-31

fcbpaint is a paint program for the Commodore VIC-20 computer.
The paint program requires +32Kb memory expansion. 

FCB = Flexible Color Bitmap (see vic20_fcb.zip)

In the most general configuration the viewer will require +16Kb.
(this depends on the number and nature of the color splits)

The editor can be restarted with SYS40960.
Saving $5100-$7E00 from a monitor should preserve the current picture
unless it has been corrupted.

Basic format:
  - bitmapped mode
  - 21 * 48 "chars"
  - each char is 8*4 pixels (hires) or 4*4 pixels (multicolor)
  - each line (pixel row) has an initial border, background and auxcolor.
   (aux = $900E, border+bg = $900F).
  - each line can split $900E and/or $900F in-line.  
   
Color splits:
  - one register can change at a time.  (eg, border+bg _or_ aux)
  - splits always start at a point and continue until the next split
    to the right or until the end of the line.
  - splits can start on any half char boundary 
    (but will happen one hires pixel late)
  - splits are compiled to machine code upon entering the viewer.
  - the only way to guarantee that a particular combination of splits
    is allowed is to enter the viewer and check.
  - there are some rules that can be followed to make success likely:
    - splits are always allowed 3 chars appart.
    - in some cases splits as close as 2 or 2.5 chars appart are allowed.


EDITOR UI
---------

     +--------------------------------------+
     |                                      |
     |   +------------------------------+   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   |                              |   |
     |   +------------------------------+   |
     |     BG[] BR[] CH[] AX[]    00/00     |
     |      [ ]  [ ]  [ ]  [ ]              |
     |                                      |
     +--------------------------------------+

The top boxes are the currently used/allocated colors at the cursor
location. 
(the nature of the pixel under the cursor is highlighted in white)

The bottom boxes are the colors that will be used when 
drawing/setting colors/creating color changes.


EDITOR KEYS
-----------

=== misc ===

<space>               : view picture
<backspace>           : return to menu
<crsr> keys           : move cursor
I,J,K,L               : panning
<home>                : move to center (54/60)

=== color selection ===

<shift-A> to <shift-P>: Background color 0-15

<ctrl-1> to <ctrl-8>  : Border color 0-7
R                     : Toggle reverse mode

<shift-1> to <shift-8>: Foreground color 0-7
T                     : Toggle multicolor mode

<cbm-A> to <cbm-P>    : Aux color 0-15

=                     : fetch local colors

0                     : cycle editor border color

=== modes ===

Q                     : toggle quick fill mode
<-                    : toggle continuous draw mode
D                     : toggle direct color mode

=== drawing ===

1                     : draw background pixel
2                     : draw border pixel (if applicable)
3                     : draw foreground pixel (and set color)
4                     : draw auxiliary pixel (if applicable)

5		      : set background color
6                     : set border color
7                     : set foreground color
8                     : set auxiliary color

F1                    : split bg/border ($900F)
F3                    : split aux       ($900E)
F5                    : delete split point


VIEWER KEYS
-----------
<space>               : return to editor or menu
<backspace>           : return to menu
1                     : cycle upper border color
2                     : cycle lower border color


KNOWN ISSUES
------------

  - Joystick does something but it's not really usable at the moment.

PLANNED
-------

  - Modes that work on unexpanded vics are possible.
    The height of the picture must be reduced (perhaps to half) and the
    Color splits repeated for each line in chunks of 4 lines.

HISTORY
-------

fcbpaint V0.6, 2013-10-31
  - pictures can now be exported as runnable binaries.
  - colors in the upper and lower border area can be changed.
  - added directory function.
  - added a selectable direct color mode.  in direct color mode selecting
    a color on the keyboard immediately updates the current setting under
    the cursor.
  - fixed annoying glitch when panning using ijkl.
  - <bs> in the viewer returns to the menu.
  - added menu option to quit the program.
  - general bug fixes.

fcbpaint V0.5, 2009-11-19
  - rewrote the color change compiler completely.  2 char splits now
    possible.
  - color allocation is correctly displayed for the far right split.

fcbpaint V0.4, 2009-11-04
  - <home> moves to the center.
  - the default setup is now multi color instead of hires.
  - split cursor now correctly indicates the split point that will be used.
    (far right will be into the right border)
  - implemented quick fill mode.  when enabled full char blocks are drawn
    always.
  - implemented continuous draw mode.  when enabled the last selected color
    is plotted as the cursor moves.

fcbpaint V0.3, 2009-11-01
  - reverse mode shown in editor.
  - currently selected editor colors are used for init.
  - right border split points can be created, deleted and updated.
  - improved color change compiler for the viewer.
  - viewer now guards against overwriting picture data in case of
    color splits spaced too close.

fcbpaint V0.2, 2009-10-25
  - split points can now be created, deleted and updated in the editor
    (bg/border/aux).
  - implemented editor "cursor" showing character corners.
  - the picture border is now visible in the editor.
  - no longer has problems to edit below line $BC.
  - cosmetic changes to the editor

fcbpaint V0.1, 2009-10-18
  - initial preview of editor, save often!

fcbpaint, 2009-09-08
  - project to implement editor started.

vicdisp, 2008-11-22
  - working prototype of the displayer, project on hold.
