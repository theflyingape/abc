 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                              �berflieger                              | 
 |-----------------------------------------------------------------------|
 | ................................. Pre-Party Release for Revision 2013 |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : .............................................. �BERFLIEGER
 GROUP        : ...................................... Akronyme Analogiker
 COMPETITION  : ..................................................... None
 PARTY        : ................................ In honor of Revision 2013
 PLATFORM     : ..................................... PAL VIC-20 + 24K RAM
 RELEASE DATE : ............................................... 26/03/2013
  
 SHORT
  DESCRIPTION : Slideshows for two newly created VIC-20 graphic modes:
                Disk 1: 96 x 256 with 8 x 1 color resolution and separate
                colors for background, border and auxiliary on each
                rasterline (FLI96)
                Disk 2: 224 x 280 with 8 x 8 color resolution (UBERMODE)

 CODE         : .................................................... Tokra
 SUPPORT:     : ..................................................... Mike

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 .................................... PAL VIC-20 + 32K RAM + uIEC/SD drive

 INSTRUCTIONS:

 Two .d64-files are included. First one has the slideshow for FLI96, the
 second one for UBERMODE.
 
 Also included are .ppm and .pgm converters in separate directories,
 explained more thorougly in the techinfo.txt.

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :

 GREETINGS TO:
 
 The members of the VIC-20 Denial-forum