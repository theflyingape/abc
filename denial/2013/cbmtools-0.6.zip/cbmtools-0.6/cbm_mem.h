/**************************************************************************
 *
 * FILE  cbm_mem.h
 * Copyright (c) 2007, 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm memory handling
 *
 ******/
#ifndef CBM_MEM_H
#define CBM_MEM_H

#include <stdint.h>

#define RAM_SIZE 0x10000

typedef uint32_t cbm_ptr_t;

struct cbm_mem {
    uint8_t *ram;
    uint8_t *usemap;
    int size;
    cbm_ptr_t low;
    cbm_ptr_t high;
};
typedef struct cbm_mem cbm_mem_t;

enum mode_t {
    MODE_NORMAL = 0,
    MODE_NEWADDR,
    MODE_RAW
};

cbm_mem_t *create_mem(void);
void destroy_mem(cbm_mem_t *cm);
void clear_mem(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea);
uint8_t get_byte(cbm_mem_t *cm, cbm_ptr_t ad);
void set_byte(cbm_mem_t *cm, cbm_ptr_t ad, uint8_t val);
uint16_t get_word(cbm_mem_t *cm, cbm_ptr_t ad);
void set_word(cbm_mem_t *cm, cbm_ptr_t ad, uint16_t val);
void copy_mem(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t da);
void copy_mem2(cbm_mem_t *scm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_mem_t *dcm, cbm_ptr_t da);
void insert_mem(uint8_t *src, int len, cbm_mem_t *dcm, cbm_ptr_t da);
void load_mem(cbm_mem_t *cm, const char *name, cbm_ptr_t la, int offs, int len, enum mode_t mode, cbm_ptr_t *aptr, int *lptr);
void save_mem(cbm_mem_t *cm, const char *name, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t la, enum mode_t mode);

#endif /* CBM_MEM_H */
/* eof */
