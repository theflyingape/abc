/**************************************************************************
 *
 * FILE  rle.h
 * Copyright (c) 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm RLE handling
 *
 ******/
#ifndef RLE_H
#define RLE_H

#include "cbm_mem.h"

void rle_pack(cbm_mem_t *dcm, cbm_mem_t *scm, cbm_ptr_t sa, cbm_ptr_t ea, char *exe_opts);

#endif /* RLE_H */
/* eof */
