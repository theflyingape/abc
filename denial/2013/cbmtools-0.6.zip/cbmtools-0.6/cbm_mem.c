/**************************************************************************
 *
 * FILE  cbm_mem.c
 * Copyright (c) 2007, 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm memory handling
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "cbm_mem.h"
#include "global.h"

cbm_mem_t *create_mem(void)
{
    cbm_mem_t *cm;
    int size = RAM_SIZE;

    cm = malloc(sizeof(cbm_mem_t));
    if (!cm)
	panic("couldn't allocate mem");

    cm->ram = malloc(size);
    cm->usemap = malloc(size);
    if ( !(cm->ram && cm->usemap) ) {
	destroy_mem(cm);
	panic("couldn't allocate mem");
    }

    clear_mem(cm, 0, size);
    cm->size = size;
    cm->low = 0;
    cm->high = 0;

    return cm;
}

void destroy_mem(cbm_mem_t *cm)
{
    if (cm) {
	free(cm->ram);
	free(cm->usemap);
	free(cm);
    }
}

uint8_t get_byte(cbm_mem_t *cm, cbm_ptr_t ad)
{
    return cm->ram[ad & (cm->size-1)];
}

void set_byte(cbm_mem_t *cm, cbm_ptr_t ad, uint8_t val)
{
    cm->ram[ad & (cm->size-1)] = val;
    cm->usemap[ad & (cm->size-1)] = 1;
}

uint16_t get_word(cbm_mem_t *cm, cbm_ptr_t ad)
{
    return get_byte(cm, ad) | (get_byte(cm, ad+1) << 8);
}

void set_word(cbm_mem_t *cm, cbm_ptr_t ad, uint16_t val)
{
    set_byte(cm, ad, val & 0xff);
    set_byte(cm, ad+1, val >> 8);
}

static int range_len(cbm_ptr_t sa, cbm_ptr_t ea)
{
    return ea - sa;
}

void clear_mem(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea)
{
    int n = range_len(sa, ea);

    memset(cm->ram + sa, 0, n);
    memset(cm->usemap + sa, 0, n);
}

void copy_mem(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t da)
{
    copy_mem2(cm, sa, ea, cm, da);
}

void copy_mem2(cbm_mem_t *scm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_mem_t *dcm, cbm_ptr_t da)
{
    int n = range_len(sa, ea);

    memmove(dcm->ram + da, scm->ram + sa, n);
    memmove(dcm->usemap + da, scm->usemap + sa, n);
}

void insert_mem(uint8_t *src, int len, cbm_mem_t *dcm, cbm_ptr_t da)
{
    memcpy(dcm->ram + da, src, len);
    memset(dcm->usemap + da, 1, len);
}

void load_mem(cbm_mem_t *cm, const char *name, cbm_ptr_t la, int offs, int len, enum mode_t mode, cbm_ptr_t *aptr, int *lptr)
{
    FILE *fp;
    int lrd;
    cbm_ptr_t ad;
    int c;

    fp = fopen(name,"rb");
    if (!fp)
	panic("couldn't open source file");

    switch (mode) {
    case MODE_NORMAL:
	/* get load address */
	la = fgetc(fp) + (fgetc(fp) << 8);
	break;
    case MODE_NEWADDR:
	/* skip load address */
	fgetc(fp);
	fgetc(fp);
	break;
    case MODE_RAW:
	/* no load address */
	break;
    default:
	break;
    }

    /* skip offset if any */
    if (offs > 0) {
	fseek(fp, offs, SEEK_CUR);
    }

    /* load file body */
    ad = la;
    lrd = 0;
    while ( c = fgetc(fp), c != EOF ) {
	set_byte(cm, ad, c);
	ad++;
	lrd++;
	/* if a max len is specified, then terminate when it has been
	   reached. */
	if (len > 0 && lrd >= len)
	    break;
    }

    fclose(fp);
    if (verbose_g)
	printf("read '%s' $%04X-$%04X.\n", name, la, ad);

    if (aptr)
	*aptr = la;
    if (lptr)
	*lptr = lrd;
}


void save_mem(cbm_mem_t *cm, const char *name, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t la, enum mode_t mode)
{
    FILE *fp;
    cbm_ptr_t ad;

    /* write destination file */
    fp = fopen(name, "wb");
    if (!fp)
	panic("couldn't open destination file\n");

    /* write load address */
    fputc(sa & 0xff, fp);
    fputc(sa >> 8, fp);

    /* write file body */
    ad = sa;
    while (ad != ea) {
	uint8_t c = get_byte(cm, ad);
	fputc(c, fp);
	ad++;
    }

    fclose(fp);
    if (verbose_g)
	printf("wrote '%s' $%04X-$%04X.\n", name, sa, ea);
}

/* eof */
