/**************************************************************************
 *
 * FILE  cpch.c
 * Copyright (c) 2007, 2012, 2013 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm file patcher
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "cbm_mem.h"
#include "global.h"
#include "params.h"

#define PROGRAM "cpch"

#define MAX_PATCHNAMES 256

const char program_g[] = PROGRAM;
char *outname_g;
char *patchnames_g[MAX_PATCHNAMES];
int num_patchnames_g;
int merge_g;

cbm_ptr_t low_g = 0xffffffff;
cbm_ptr_t high_g = 0x00000000;

void patch_ram(cbm_mem_t *cm, const char *name);
void write_patch(cbm_mem_t *cm, const char *name);

int main(int argc, char *argv[])
{
    int c;
    char *srcname;
    char *save_range;

    /* defaults */
    srcname = "";
    verbose_g = 0;
    debug_g = 0;
    outname_g = "a.out";
    save_range = "";
    num_patchnames_g = 0;
    merge_g = 0;

    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "r:p:o:mdvVh"))) {
        switch (c) {
	
	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set verbose */
	case 'v':
	    verbose_g = 1;
	    break;

	/* set debug */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf(stdout, PROGRAM " (" PACKAGE ") " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " (" PACKAGE ") " VERSION ": cbm binary patcher\n"
"Copyright (c) 2007, 2012, 2013 Daniel Kahlin <daniel@kahlin.net>\n"
"Written by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"usage: " PROGRAM " [-r<range>][-p<patch>][-o<name>][-m][-v][-d][-h][-V] <source>...\n"
"\n"
"Valid options:\n"
"    -r              specify save range\n"
"    -p              patch file\n"
"    -o              output file\n"
"    -m              merge patch files\n"
"    -v              be verbose\n"
"    -d              debugging output\n"
"    -h              displays this help text\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* specify save range */
	case 'r':
	    save_range = optarg;
	    break;

	/* set output file */
	case 'o':
	    outname_g = optarg;
	    break;

	/* set patchname file */
	case 'p':
	    patchnames_g[num_patchnames_g] = optarg;
	    num_patchnames_g++;
	    break;

	/* set merge mode */
	case 'm':
	    merge_g = 1;
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     */
    int num_files = argc-optind;
    if (!merge_g) {
	if (num_files < 1)
	    panic("too few arguments");
	srcname = argv[optind];
    } else {
	if (num_files)
	    panic("too many arguments");
    }

    cbm_mem_t *cm = create_mem();

    if (!merge_g) {
	cbm_ptr_t addr;
	int len;
	file_t f;

	f = parse_filename(srcname);
	load_mem(cm, f.name, f.la, f.offs, f.len, f.mode, &addr, &len);
	low_g = addr;
	high_g = addr + len;
    }

    /* read patch files */
    int i;
    for (i = 0; i < num_patchnames_g; i++) {
	patch_ram(cm, patchnames_g[i]);
    }

    if (!merge_g) {
	parse_range(save_range, &low_g, &high_g);
	/* write destination file */
	save_mem(cm, outname_g, low_g, high_g, 0, MODE_NORMAL);
    } else {
	write_patch(cm, outname_g);
    }

    destroy_mem(cm);
    exit(0);
}


void patch_ram(cbm_mem_t *cm, const char *name)
{
    FILE *fp;
    int len;
    uint8_t buf[256];
    uint8_t *bp;
    int num;
    int cnt;

    fp = fopen(name, "rb");
    if (!fp)
	panic("couldn't open patch file for reading");

    if (verbose_g) {
	printf("patch file '%s':\n", name);
    }
    /* 
     * parse header
     */

    /* skip start addr */
    fgetc(fp);
    fgetc(fp);
    /* read header */
    len = fgetc(fp) | fgetc(fp) << 8;
    fread(buf, 1, len, fp);
    bp = buf;

    /* check signature */
    if (len >= 4 && strncmp((char *)bp, "PTCH", 4))
	panic("not a patch file");
    bp += 4;
    len -= 4;


    /*
     * parse chunks
     */
    num = 0;
    cnt = 0;
    while (1) {
	int i;
	cbm_ptr_t addr;
	int len;
	addr = fgetc(fp) | fgetc(fp) << 8;
	len = fgetc(fp) | fgetc(fp) << 8;
	if ( len == 0 || feof(fp) ) {
	    break;
	}
	for (i = 0; i < len; i++) {
	    uint8_t c = fgetc(fp);
	    set_byte(cm, addr + i, c);
	}

	if (verbose_g) {
	    printf("  chunk %d: $%04x-$%04x (%d bytes)\n", num, addr, addr + len-1, len);
	}

	if (addr < low_g) {
	    low_g = addr;
	}

	if (addr + len > high_g) {
	    high_g = addr+len;
	}

	cnt += len;
	num++;
    }
    fclose(fp);
    if (verbose_g) {
	printf("  %d patch bytes in %d chunks.\n", cnt, num);
    }
}


void write_patch(cbm_mem_t *cm, const char *name)
{
    FILE *fp;
    int num;
    int cnt;
    int len;

    fp = fopen(name, "wb");
    if (!fp)
	panic("couldn't open patch file for writing");

    if (verbose_g) {
	printf("patch file '%s':\n", name);
    }
    /* 
     * write header
     */

    /* skip start addr */
    fputc(0, fp);
    fputc(0, fp);
    len = 4;
    fputc(len & 0xff, fp);
    fputc(len >> 8, fp);
    fputc('P', fp);
    fputc('T', fp);
    fputc('C', fp);
    fputc('H', fp);

    /*
     * write chunks
     */
    num = 0;
    cnt = 0;
    cbm_ptr_t ad = low_g;
    len = 0;
    cbm_ptr_t addr = ad;
    while (1) {
	if (ad < high_g && cm->usemap[ad]) {
	    if (len == 0) {
		addr = ad;
	    }
	    len++;
	} else {
	    if (len > 0 ) {
		int i;
		fputc(addr & 0xff, fp);
		fputc(addr >> 8, fp);
		fputc(len & 0xff, fp);
		fputc(len >> 8, fp);
		for (i = 0; i < len; i++) {
		    fputc(cm->ram[addr+i], fp);
		}
		if (verbose_g) {
		    printf("  chunk %d: $%04x-$%04x (%d bytes)\n", num, addr, addr + len-1, len);
		}
		num++;	
		cnt += len;
	    }
	    if (ad >= high_g)
		break;
	    len = 0;
	}

	ad++;
    }

    /* write end marker */
    fputc(0, fp);
    fputc(0, fp);
    fputc(0, fp);
    fputc(0, fp);

    fclose(fp);
    if (verbose_g) {
	printf("  %d patch bytes in %d chunks.\n", cnt, num);
    }
}


/* eof */
