/**************************************************************************
 *
 * FILE  cld.c
 * Copyright (c) 2007, 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm file linker
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "cbm_mem.h"
#include "global.h"
#include "params.h"
#include "rle.h"

#define PROGRAM "cld"

const char program_g[] = PROGRAM;
char *outname_g;

cbm_ptr_t low_g = 0xffffffff;
cbm_ptr_t high_g = 0x00000000;

int main(int argc, char *argv[])
{
    int c;
    char **srcnames;
    char *save_range;
    int make_exe;
    char *exe_opts;

    /* defaults */
    verbose_g = 0;
    debug_g = 0;
    outname_g = "a.out";
    save_range = "";
    make_exe = 0;
    exe_opts = "";

    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "r:xX:o:dvVh"))) {
        switch (c) {
	
	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set verbose */
	case 'v':
	    verbose_g = 1;
	    break;

	/* set debug */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf(stdout, PROGRAM " (" PACKAGE ") " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " (" PACKAGE ") " VERSION ": cbm binary linker\n"
"Copyright (c) 2007, 2012 Daniel Kahlin <daniel@kahlin.net>\n"
"Written by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"usage: " PROGRAM " [-r<range>][-x][-X<opts>][-o<name>][-v][-d][-h][-V] <source>...\n"
"\n"
"Valid options:\n"
"    -r              specify save range\n"
"    -x              produce executable output\n"
"    -X <opts>       options for executable\n"
"    -o              output file\n"
"    -v              be verbose\n"
"    -d              debugging output\n"
"    -h              displays this help text\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* specify save range */
	case 'r':
	    save_range = optarg;
	    break;

	/* produce executable output */
	case 'x':
	    make_exe = 1;
	    break;

	/* options for executable */
	case 'X':
	    exe_opts = optarg;
	    break;

	/* set output file */
	case 'o':
	    outname_g = optarg;
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     * we expect two more arguments (inname, outname)
     */
    int num_files = argc-optind;
    if (num_files < 1)
	panic("too few arguments");
    srcnames = &argv[optind];

    cbm_mem_t *cm = create_mem();
    int i;

    for (i = 0; i < num_files; i++) {
	cbm_ptr_t sa, ea;
	int len;
	char *name = srcnames[i];
	file_t f;

	f = parse_filename(name);
	load_mem(cm, f.name, f.la, f.offs, f.len, f.mode, &sa, &len);
	ea = sa + len;

	if (sa < low_g) {
	    low_g = sa;
	}
	if (ea > high_g) {
	    high_g = ea;
	}
    }

    parse_range(save_range, &low_g, &high_g);

    if (make_exe) {
	cbm_mem_t *dcm = create_mem();
	rle_pack(dcm, cm, low_g, high_g, exe_opts);
	destroy_mem(cm);
	cm = dcm;
	low_g = cm->low;
	high_g = cm->high;
    }

    save_mem(cm, outname_g, low_g, high_g, 0, MODE_NORMAL);

    destroy_mem(cm);
    
    exit(0);
}

/* eof */
