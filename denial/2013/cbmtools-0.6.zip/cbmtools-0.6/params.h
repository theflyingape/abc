/**************************************************************************
 *
 * FILE  params.h
 * Copyright (c) 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   parameter parsing
 *
 ******/
#ifndef PARAMS_H
#define PARAMS_H

#include "cbm_mem.h"

typedef struct {
    char *name;
    enum mode_t mode;
    cbm_ptr_t la;
    int offs;
    int len;
} file_t;

int parse_value(char *str);
void parse_range(char *str, cbm_ptr_t *low, cbm_ptr_t *high);
file_t parse_filename(char *str);

#endif /* PARAMS_H */
/* eof */
