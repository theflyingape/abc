/**************************************************************************
 *
 * FILE  global.c
 * Copyright (c) 2007, 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Global variables and functions
 *
 ******/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "global.h"

int verbose_g;
int debug_g;

void panic(const char *str, ...)
{
    va_list args;

    fprintf(stderr, "%s: ", program_g);
    va_start(args, str);
    vfprintf(stderr, str, args);
    va_end(args);
    fputc('\n', stderr);
    exit(1);
}

/* eof */
