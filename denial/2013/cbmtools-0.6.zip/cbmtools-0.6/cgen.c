/**************************************************************************
 *
 * FILE  cgen.c
 * Copyright (c) 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm test file generator
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

#include "cbm_mem.h"
#include "checkers.h"
#include "global.h"
#include "params.h"

#define PROGRAM "cgen"

const char program_g[] = PROGRAM;
char *outname_g;

cbm_ptr_t low_g = 0xffffffff;
cbm_ptr_t high_g = 0x00000000;

void generate(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t load, unsigned int seed);

int main(int argc, char *argv[])
{
    int c;
    char *srcname;
    unsigned int seed;
    cbm_ptr_t sa, ea, load;

    /* defaults */
    verbose_g = 0;
    debug_g = 0;
    srcname = 0;
    outname_g = "a.out";
    seed = time(0);
    sa = 0x0801;
    ea = 0xd000;
    load = 0x0801;

    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "s:e:j:S:o:dvVh"))) {
        switch (c) {
	
	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set verbose */
	case 'v':
	    verbose_g = 1;
	    break;

	/* set debug */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf(stdout, PROGRAM " (" PACKAGE ") " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " (" PACKAGE ") " VERSION ": cbm self-checking test file generator\n"
"Copyright (c) 2012 Daniel Kahlin <daniel@kahlin.net>\n"
"Written by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"usage: " PROGRAM " [-s<addr>][-e<addr>][-j<addr>][-S<seed>][-o<name>][-v][-d][-h][-V] srcnames...\n"
"\n"
"Valid options:\n"
"    -s              start address\n"
"    -e              end address\n"
"    -j              jump address\n"
"    -S              set fixed seed\n"
"    -o              output file\n"
"    -v              be verbose\n"
"    -d              debugging output\n"
"    -h              displays this help text\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* set start addr */
	case 's':
	    sa = parse_value(optarg);
	    break;

	/* set end addr */
	case 'e':
	    ea = parse_value(optarg);
	    break;

	/* set jump addr */
	case 'j':
	    load = parse_value(optarg);
	    break;

	/* set seed */
	case 'S':
	    seed = parse_value(optarg);
	    break;

	/* set output file */
	case 'o':
	    outname_g = optarg;
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     * we expect two more arguments (inname, outname)
     */
    int num_files = argc-optind;
    if (num_files > 1)
	panic("excessive arguments");

    if (num_files) {
	srcname = argv[optind];
    }

    cbm_mem_t *cm = create_mem();

    if (verbose_g) {
	if (load == 0x0801) {
	    printf("jump address $%04X (or RUN).\n", 0x0815);
	} else {
	    printf("jump address $%04X.\n", load);
	}
	printf("using seed 0x%08x.\n", seed);
    }

    generate(cm, sa, ea, load, seed);


    save_mem(cm, outname_g, low_g, high_g, 0, MODE_NORMAL);

    destroy_mem(cm);
    
    exit(0);
}



typedef struct {
    uint8_t a;
    uint8_t b;
} fl8_t;

const fl8_t s0 = { 0, 0 };

static uint8_t add1(uint8_t a, uint8_t b)
{
    int c = a + b;
    return (c & 0xff) + (c >> 8);
}

static fl8_t fl8sum(fl8_t s, uint8_t v)
{
    s.a = add1(s.a,v);
    s.b = add1(s.b,s.a);
    return s;
}

static fl8_t fl8range(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, fl8_t s)
{
    cbm_ptr_t ad = sa;

    while (ad < ea) {
	uint8_t d = get_byte(cm, ad);
	s = fl8sum(s, d);
	ad++;
    }

    return s;
}

static int fl8cmp(fl8_t s1, fl8_t s2)
{
    return (s1.a == s2.a && s1.b == s2.b);
}

static fl8_t fl8random(void)
{
    fl8_t s;
    s.a = random();
    s.b = random();
    if (s.a == 0)
	s.a = 0xff;
    if (s.b == 0)
	s.b = 0xff;
    return s;
}


static void gen_random_range(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, int mode)
{
    cbm_ptr_t ad = sa;
    int n = 0;
    uint8_t v = 0;
    int f = 0;
    while (ad < ea) {
	if (n == 0) {
	    n = (random() & 0xff) + 1;
	    f = random() & 1;
	    v = random();
	}
	if (f) {
	    v = random();
	}
	set_byte(cm, ad, v);
	ad++;
	n--;
    }
}

static int gen_collision(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t ca, fl8_t my_s)
{
    fl8_t s, init_s;
    init_s = fl8range(cm, sa, ca, s0);

    /* find collision */
    int i, j, k;
    for (i = 0x00; i < 0x100; i++) {
	set_byte(cm, ca+0, i);
	for (j = 0x00; j < 0x100; j++) {
	    set_byte(cm, ca+5, j);
	    for (k = 0x00; k < 0x100; k++) {
		set_byte(cm, ca+8, k);

		s = fl8range(cm, ca, ea, init_s);
		if (fl8cmp(s, my_s)) {
		    return 1;
		}
	    }
	}
    }

    return 0;
}

void generate(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, cbm_ptr_t load, unsigned int seed)
{
    FixStruct *fs = fs_default_sys;
    cbm_ptr_t ad = load;
    int rm = 0;

    if (load != 0x0801) {
	fs = fs_default_sysless;
    }
    srandom(seed);


    insert_mem(fs->data, fs->len, cm, ad);
    ad += fs->len;
    set_word(cm, ad, sa);
    ad += 2;
    set_word(cm, ad, ea);
    ad += 2;
    fl8_t my_s = fl8random();
    set_byte(cm, ad, my_s.a);
    ad++;
    set_byte(cm, ad, my_s.b);
    ad++;
    set_byte(cm, ad, 0x8a);
    ad++;

    /* process fields to fill in */
    FixEntry *fe = fs->fix_entry;
    int reloc_offs = -fs->addr + load;
    while (fe->type != ftEnd) {
	uint16_t val;
	cbm_ptr_t addr = fe->addr + reloc_offs;
	switch (fe->type) {
	case ftRelocAdj:
	    val = get_word(cm, addr);
	    val += reloc_offs;
	    set_word(cm, addr, val);
	    break;
	default:
	    break;
	}
	fe++;
    }

    if (sa < load) {
	gen_random_range(cm, sa, load, rm);
    }

    gen_random_range(cm, ad, ea, rm);

    /* setup a fake $00 ddr value if $00 isn't included in the range */
    if (sa > 0x00) {
	set_byte(cm, 0x00, 0x2f);
    }
    if (sa < 0x02) {
	while (1) {
	    /* make sure $00/$01 contains working values */
	    uint8_t ddr = get_byte(cm, 0x00);
	    uint8_t iop = get_byte(cm, 0x01);
	    iop &= ddr;
	    iop &= 0x3f;
	    set_byte(cm, 0x00, ddr);
	    set_byte(cm, 0x01, iop);
	    iop |= ~ddr;
	    iop &= 0x7;
	    if (iop == 0x05 || iop == 0x06 || iop == 0x07)
		break;

	    /* not ok, regenerate */
	    gen_random_range(cm, sa, 0x02, rm);
	}
    }

#define COLLISION_DIST 128
    gen_collision(cm, sa, ea, ea - COLLISION_DIST, my_s);

    /* verify */
    fl8_t vs = fl8range(cm, sa, ea, s0);
    if (!fl8cmp(vs, my_s)) {
	panic("failed to find collision!");
    }

    low_g = sa;
    high_g = ea;
}

/* eof */
