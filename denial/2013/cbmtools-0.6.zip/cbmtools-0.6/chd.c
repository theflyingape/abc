/**************************************************************************
 *
 * FILE  chd.c
 * Copyright (c) 2007, 2012, 2013 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   'hd' like dump for cbm files
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "params.h"

#define PROGRAM "chd"

const char program_g[] = PROGRAM;

int overload_g;
uint32_t overload_addr_g;
int longaddr_g;
int32_t loadaddr_g;
int rawfile_g;

void dump_file(FILE *fp);
void dump_line(uint32_t addr, uint8_t *buf, int len);

int main(int argc, char *argv[])
{
    int c;

    /* defaults */
    verbose_g = 0;
    debug_g = 0;
    overload_g = 0;
    longaddr_g = 0;
    loadaddr_g = -1;
    rawfile_g = 0;

    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "nl:LO:dvVh"))) {
        switch (c) {
	
	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set verbose */
	case 'v':
	    verbose_g = 1;
	    break;

	/* set debug */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf(stdout, PROGRAM " (" PACKAGE ") " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " (" PACKAGE ") " VERSION ": cbm binary hexdump\n"
"Copyright (c) 2007, 2012, 2013 Daniel Kahlin <daniel@kahlin.net>\n"
"Written by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"usage: " PROGRAM " [-n][-l<addr>][-L][-O[d|t|<addr>][-v][-d][-h][-V] <file>...\n"
"\n"
"Valid options:\n"
"    -n              file has no load address\n"
"    -l              override load address\n" 
"    -L              24-bit addressing (default: 16-bit)\n" 
"    -O              consider pointer overloading\n" 
"    -v              be verbose\n"
"    -d              debugging output\n"
"    -h              displays this help text\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* set raw mode */
	case 'n':
	    rawfile_g = 1;
	    break;

	/* set Load address */
	case 'l':
	    loadaddr_g = parse_value(optarg);
	    break;

	/* set Long addressing */
	case 'L':
	    longaddr_g = 1;
	    break;

	/* set Overloading */
	case 'O':
	    overload_g = 1;
	    switch (optarg[0]) {
	    case 't':
		overload_addr_g = 0xac;
		break;
	    case 'd':
		overload_addr_g = 0xae;
		break;
	    default:
		overload_addr_g = parse_value(optarg);
		break;
	    }
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     */
    int i;
    int num_args = argc-optind;
    char **srcnames = &argv[optind];

    /* if no arguments, dump from stdin */
    if (num_args == 0) {
	dump_file(stdin);
	exit(0);
    }

    /* if one or more arguments, dump from the listed files */
    for (i = 0; i < num_args; i++) {
	FILE *fp;
	char *srcname;

	srcname = srcnames[i];
	fp = fopen(srcname, "rb");
	if (!fp) {
	    panic("couldn't open file");
	}

	if (num_args > 1) {
	    printf("--- %s ---\n", srcname);
	}

	dump_file(fp);

	fclose(fp);
    }

    exit(0);
}



void dump_file(FILE *fp)
{
    uint32_t addr;
    uint32_t lowad;
    uint32_t highad;
    int nread = 0;

    if (!rawfile_g) {
	addr = fgetc(fp) + (fgetc(fp) << 8);
	nread += 2;
    } else {
	addr = 0x0800;
    }
    if (loadaddr_g >= 0)
	addr = loadaddr_g;

    uint8_t buf[16];
    lowad=addr;
    highad=addr;
    uint32_t ad = addr;
    while (!feof(fp)) {
	int n;
	int done = 0;
	uint32_t next_ad = ad;
	for (n=0; (n < 16) & !done; n++) {
	    int v = fgetc(fp);
	    uint8_t c = v;
	    if (v == EOF)
		break;
	    nread++;
	    buf[n] = c;

	    if (next_ad < lowad)
		lowad = next_ad;
	    if (next_ad+1 > highad)
		highad = next_ad+1;
	    /* check for overloading */
	    if (overload_g) {
		if (next_ad == overload_addr_g && c != (next_ad & 0xff)) {
		    next_ad = (next_ad & 0xff00) | c;
		    done = 1;
		}
		if (next_ad == (overload_addr_g+1) && c != ((next_ad >> 8) & 0xff)) {
		    next_ad = (c << 8) | (next_ad & 0xff);
		    done = 1;
		}
	    }
	    /* next address */
	    next_ad++;
	    if (!longaddr_g)
		next_ad &= 0xffff;
	}
	dump_line(ad, buf, n);
	ad = next_ad;
    }

    if (ad > highad)
	highad = ad;

    int nblks = (nread+253)/254;
    if (longaddr_g) {
	printf("dumped $%06X-$%06X (%d %s, %d %s)\n",lowad, highad, nread, nread==1?"byte":"bytes", nblks, nblks==1?"block":"blocks");
    } else {
	lowad &= 0xffff;
	highad &= 0xffff;
	printf("dumped $%04X-$%04X (%d %s, %d %s)\n",lowad, highad, nread, nread==1?"byte":"bytes", nblks, nblks==1?"block":"blocks");
    }
}


char printable(uint8_t c)
{
    if (c>0x00 && c<='Z'-0x40)
	return c|0x60;
    if (c<0x20 || c>0x7e)
	return '.';
    return c;
}

#define MAXLINELEN 16
void dump_line(uint32_t addr, uint8_t *buf, int len)
{
    int i;
    if (!len)
	return;

    if (longaddr_g)
	printf("%06X ",addr);
    else
	printf("%04X ",addr);

    for (i = 0; i < MAXLINELEN; i++) {
	if (i == 8)
	    printf(" ");
	if (i < len)
	    printf(" %02X",buf[i]);
	else
	    printf("   ");
    }
    printf(" |");
    for (i = 0; i < len; i++) {
	printf("%c",printable(buf[i]));
    }
    printf("|");
    printf("\n");
}
/* eof */
