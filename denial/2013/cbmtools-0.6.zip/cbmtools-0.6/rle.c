/**************************************************************************
 *
 * FILE  rle.c
 * Copyright (c) 2012 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   cbm RLE handling
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "cbm_mem.h"
#include "global.h"
#include "rle.h"

#include "depackers.h"

#define MAX_RLE_ENTRIES 0x10000
struct rle_entry {
    int n;
    uint8_t val;
};
typedef struct rle_entry rle_entry_t;

rle_entry_t rs[MAX_RLE_ENTRIES];


static void scan_space(cbm_mem_t *cm, cbm_ptr_t sa, cbm_ptr_t ea, int min_limit, int c)
{
    cbm_ptr_t ad;
    int i = 0;
    int n = 0;
    int last = -1;

    int max_limit = 256;

    for (ad = sa; ad < ea; ad++) {
	uint8_t v = get_byte(cm, ad);
	if (v != last || n >= max_limit) {

	    while (n) {
		if (n > min_limit || last == c) {
		    rs[i].n = n;
		    rs[i].val = last;
		    i++;
		    n = 0;
		} else {
		    rs[i].n = 1;
		    rs[i].val = last;
		    i++;
		    n--;
		}
	    }

	    last = v;
	}

	n++;
    }

    while (n) {
	if (n > min_limit || last == c) {
	    rs[i].n = n;
	    rs[i].val = last;
	    i++;
	    n = 0;
	} else {
	    rs[i].n = 1;
	    rs[i].val = last;
	    i++;
	    n--;
	}
    }

    /* end marker */
    rs[i].n = 0;


    if (debug_g) {
	i = 0;
	while (rs[i].n) {
	    printf("run $%02X * %d\n", rs[i].val, rs[i].n);
	    i++;
	}
    }
}



static uint8_t find_code(rle_entry_t *re, int guard)
{
    int i;
    int bins[256];
    int m;
    uint8_t c;

    memset(bins, 0, sizeof(bins));


    rle_entry_t *last_gain = re;
    while (re->n) {
	if ( re->n == 1 ) {
	    bins[re->val]++;
	}
	if ( re->n > 1 ) {
	    /* keep track on where we gained anything last */
	    last_gain = re;
	}
	re++;
    }

    
    if (guard) {
	/* disqualify any codes used after the last gain */
	re = last_gain + 1;
	while (re->n) {
	    bins[re->val] = INT_MAX;
	    re++;
	}
    }

    m = INT_MAX;
    c = 0;
    for (i = 0; i < 256; i++) {
	if (bins[i] < m) {
	    m = bins[i];
	    c = i;
	}
    }

    return c;
}


static int gen_out(rle_entry_t *re, uint8_t c, uint8_t *buf)
{
    int l;

    l = 0;

    while (re->n) {
	int n = re->n;
	uint8_t v = re->val;

	if (n == 1) {
	    if (v != c) {
		buf[l++] = v;
	    } else {
		buf[l++] = c;
		buf[l++] = 0;
	    }
	} else {
	    buf[l++] = c;
	    buf[l++] = n-1;
	    buf[l++] = v;
	}

	re++;
    }

    return l;
}


#define MAX_BUF_LEN 0x10000
uint8_t buf[MAX_BUF_LEN];

typedef struct {
    cbm_ptr_t sa;
    cbm_ptr_t ea;
} range_t;

static range_t avoid35[] = {
    { 0xd000, 0xe000  },
    { 0, 0 }
};

static range_t avoid36[] = {
    { 0xd000, 0xe000  },
    { 0xe000, 0x10000 },
    { 0, 0 }
};

static range_t avoid37[] = {
    { 0xa000, 0xc000  },
    { 0xd000, 0xe000  },
    { 0xe000, 0x10000 },
    { 0, 0 }
};

static int is_range(range_t *r, cbm_ptr_t sa, cbm_ptr_t ea)
{
    while (r->sa != r->ea) {
	if (sa >= r->sa && sa < r->ea)
	    return 1;
	if (ea >= r->sa && ea < r->ea)
	    return 1;

	if (sa < r->sa && ea >= r->ea)
	    return 1;
	
	r++;
    }

    return 0;
}

static FixStruct *find_variant(int flags)
{
    Variant *var;
    for (var = variants; var->fs; var++) {
	if (var->flags == flags) {
	    return var->fs;
	}
    }
    return 0;
}


struct {
    cbm_ptr_t loadback;
    uint8_t mem;
    cbm_ptr_t jump;
    int flags;
} config;

static void get_options(char *opts)
{
    char *next;
    char *curr;

    if (*opts == 0)
	return;

    curr = opts;
    do {
	char *val;
        next = strchr(curr, ',');
        if (next) {
            *next++ = 0;
        }
	
        val = strchr(curr, '=');
	if (val) {
	    *val++ = 0;
	}

        if (debug_g) {
            printf("flag: %s, val: %s\n", curr, val);
	}

        if (strcmp("full",curr) == 0) {
            config.flags |= FULL_MEM;
	    continue;
	}
        if (strcmp("sei",curr) == 0) {
            config.flags &= ~HAVE_CLI;
	    continue;
	}
        if (strcmp("sysless",curr) == 0) {
            config.flags |= SYS_LESS;
	    continue;
	}
        if (strcmp("mem",curr) == 0) {
	    uint8_t v;
	    v = strtoul(val, 0, 0);
            config.mem = v;
	    continue;
	}
        if (strcmp("jmp",curr) == 0) {
	    uint16_t v;
	    v = strtoul(val, 0, 0);
            config.jump = v;
	    continue;
	}
        if (strcmp("load",curr) == 0) {
	    uint16_t v;
	    v = strtoul(val, 0, 0);
            config.loadback = v;
	    continue;
	}
	panic("unknown option: %s", curr);
    } while ( (curr = next) );

}


struct {
    cbm_ptr_t ad;
    int len;
    uint8_t val;
    cbm_ptr_t entry;
} space;

void rle_pack(cbm_mem_t *dcm, cbm_mem_t *scm, cbm_ptr_t sa, cbm_ptr_t ea, char *exe_opts)
{
    uint8_t c;
    int l0, l1, l2;
    cbm_mem_t *cm = 0;
    FixStruct *fs_normal = 0;
    FixStruct *fs_fullmem = 0;
    FixStruct *fs = 0;


    l0 = ea - sa;

    config.loadback = 0x0801;
    config.mem = 0x37;
    config.jump = sa;
    config.flags = HAVE_CLI;

    get_options(exe_opts);

    /* force sysless if load back is non-standard. */
    if (config.loadback != 0x0801) {
	config.flags |= SYS_LESS;
    }

    fs_normal = find_variant(config.flags);
    fs_fullmem = find_variant(config.flags | FULL_MEM);

    fs = fs_normal;

    /* find lowest mem possible using the selected decruncher */
    cbm_ptr_t lowest_mem = 0;
    cbm_ptr_t st = 0;
    cbm_ptr_t ed = 0;
    /* process fields to fill in */
    FixEntry *fe2 = fs->fix_entry;
    while (fe2->type != ftEnd) {
	cbm_ptr_t addr = fe2->addr;
	switch (fe2->type) {
	case ftDepackStore:
	    st = addr;
	    break;
	case ftDepackOverlap:
	    ed = addr;
	    break;
	default:
	    break;
	}
	fe2++;
    }
    lowest_mem = ed - st + 0x0001;
    if (debug_g) {
	printf("packer: lowest=$%04X\n", lowest_mem);
    }

    /******
     *
     * Perform full mem remapping.
     *
     */
    if ( (config.flags & FULL_MEM) || (sa < lowest_mem) ) {
	cbm_ptr_t ad;
	rle_entry_t *re;
	int copydown_len;

	fs = fs_fullmem;

	copydown_len = (fs+1)->len;
	if (debug_g) {
	    printf("packer: length of copydown=$%02X bytes\n", copydown_len);
	}

	/* clone source data */
	cm = create_mem();
	copy_mem2(scm, sa, ea, cm, sa);
	scm = cm;

	/* set up memory if required */
	if (sa > 0x00) {
	    set_byte(scm, 0x00, 0x2f);
	}
	if (sa > 0x01) {
	    set_byte(scm, 0x01,config.mem);
	}
	
	/* make sure $00/$01 contains working values */
	uint8_t ddr = get_byte(scm, 0x00);
	uint8_t iop = get_byte(scm, 0x01);
	range_t *avoid_r = avoid37;
	iop |= ~ddr;
	iop &= 0x07;
	switch (iop) {
	case 0x05:
	    avoid_r = avoid35;
	    break;
	case 0x06:
	    avoid_r = avoid36;
	    break;
	case 0x07:
	    avoid_r = avoid37;
	    break;
	default:
	    panic("invalid $00/$01 combination! ($%02X/$%02X)", get_byte(scm, 0x00), get_byte(scm, 0x01));
	    break;
	}
	if (debug_g) {
	    printf("packer: effective mem=$%02X\n", iop);
	}

	/* scan for a large enough space to put the copydown */
	scan_space(scm, sa, ea, 1, -1);
	re = rs;
	ad = sa;
	space.len = 0;
	while (re->n) {
	    /* this should consider lowest_mem for the full mem version. */
	    /* check both halves  of the range */
	    if (re->n >= copydown_len && ad > lowest_mem) {
		if ( !is_range(avoid_r, ad, ad+copydown_len) ) {
		    space.ad = ad;
		    space.len = re->n;
		    space.val = re->val;
		}
		//		break;
	    }
	    ad += re->n;
	    re++;
	}
	if (space.len == 0) {
	    panic("no space found for fullmem!");
	}
	if (debug_g) {
	    printf("packer: copydown @ $%04X-$%04X (%d * $%02X)\n", space.ad, space.ad+space.len, space.len, space.val);
	}

	FixStruct *dp = fs + 1;

	insert_mem(dp->data, dp->len, scm, space.ad);
	space.len = dp->len;

	if (verbose_g) {
	    printf("packer: using $%04X-$%04X for copydown\n", space.ad, space.ad+space.len);
	}

	cbm_ptr_t cd_sa = 0;
	cbm_ptr_t cd_ea = 0;
	/* process fields to fill in */
	FixEntry *fe = dp->fix_entry;
	while (fe->type != ftEnd) {
	    uint16_t val;
	    cbm_ptr_t addr = fe->addr - dp->addr + space.ad;
	    switch (fe->type) {
	    case ftCopyDownData:
		cd_sa = addr;
		break;
	    case ftCopyDownDataEnd:
		cd_ea = addr;
		break;
	    case ftCopyDownEntry:
		space.entry = addr;
		break;
	    case ftCopyDownSrc:
		val = space.ad - 1;
		set_word(scm, addr, val);
		break;
	    case ftCleanupLen:
		/* set up values for the copy loop in I/O space */
		set_byte(scm, addr, space.len);
		break;
	    case ftCleanupVal:
		/* set up values for the copy loop in I/O space */
		set_byte(scm, addr, space.val);
		break;
	    default:
		break;
	    }
	    fe++;
	}
	int cd_len = cd_ea - cd_sa;

	/* remap low mem */
	copy_mem(scm, 0x0000, 0x0000 + cd_len, cd_sa);
	/* clear area that was remapped */
	clear_mem(scm, 0x0000, 0x0000 + cd_len);
	/* fix start address (is the guard redundant?) */
	if (sa < (0x0000 + cd_len)) {
	    sa = 0x0000 + cd_len;
	}
    }

    /******
     *
     * Perform RLE compression
     *
     */
    scan_space(scm, sa, ea, 2, -1);

    c = find_code(rs, 1);

    l1 = gen_out(rs, c, buf);

    /* rescan only needed if code occurs in stream. */
    scan_space(scm, sa, ea, 2, c);
    l2 = gen_out(rs, c, buf);

    if (verbose_g) {
	printf("packer: code $%02X, l0=%d, l1=%d, l2=%d\n", c, l0, l1, l2);
    }


    /******
     *
     * Map decruncher
     *
     */
    FixStruct *dp = fs;
    int loadback_offs = -dp->addr + config.loadback;
    cbm_ptr_t ad = config.loadback;

    if ( (ad + dp->len + l2) > 0x10000 ) {
	panic("data doesn't fit! ($%04X-$%04X)", ad, ad+dp->len+l2);
    }

    insert_mem(dp->data, dp->len, dcm, ad);
    ad += dp->len;
    insert_mem(buf, l2, dcm, ad);
    ad += l2;
    

    /* process fields to fill in */
    FixEntry *fe = dp->fix_entry;
    while (fe->type != ftEnd) {
	uint16_t val;
	cbm_ptr_t addr = fe->addr + loadback_offs;
	switch (fe->type) {
	case ftDepackCode:
	    set_byte(dcm, addr, c);
	    break;
	case ftDepackReadAddrLSB:
	    val = 0x10000 - l2;
	    set_byte(dcm, addr, val & 0xff);
	    break;
	case ftDepackReadAddrMSB:
	    val = 0x10000 - l2;
	    set_byte(dcm, addr, val >> 8);
	    break;
	case ftDepackWriteAddr:
	    set_word(dcm, addr, sa);
	    break;
	case ftDepackCopyUpSrc:
	    set_word(dcm, addr, ad );
	    break;
	case ftDepackCopyUpPages:
	    set_byte(dcm, addr, ( (l2 + 0xff) >> 8 ) + 1 );
	    break;
	case ftDepackJumpAddr:
	    set_word(dcm, addr, config.jump);
	    break;
	case ftDepackMemory:
	    set_byte(dcm, addr, config.mem);
	    break;


	case ftLoadBackAdj:
	    val = get_word(dcm, addr);
	    val += loadback_offs;
	    set_word(dcm, addr, val);
	    break;

	/*
	 * Fix types related to the full mem configuration
	 *
	 */
	case ftDepackCleanAddr:
	    set_word(dcm, addr, space.entry);
	    break;
	case ftCleanupAddr:
	    set_word(dcm, addr, space.ad - 1);
	    break;
#if 0
	case ftCleanupLen:
	    set_byte(dcm, addr, space.len);
	    break;
	case ftCleanupVal:
	    set_byte(dcm, addr, space.val);
	    break;
#endif

	default:
	    break;
	}
	fe++;
    }


    dcm->low = config.loadback;
    dcm->high = ad;

    destroy_mem(cm);
}

/* eof */
