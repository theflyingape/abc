Yacht is a public domain dice game, similar to the Latin American game Generala, the English game of Poker Dice, the Scandinavian Yatzy, and the Cheerio (dice game).

It is also known as the predecessor of Yahtzee (trademarked in the United States by Hasbro).

Gameplay
--------
Yacht can be played solitaire or by any number players.

Players take turns rolling five dice. After each roll, the player chooses which dice to keep, and which to reroll.
A player may reroll some or all of the dice up to two times on a turn. The player with the highest total score wins the game.

Scoring
-------
The following combinations earn points:

Upper Section
-------------
Ones: The sum of all dice showing the number 1.
Twos: The sum of all dice showing the number 2.
Threes: The sum of all dice showing the number 3.
Fours: The sum of all dice showing the number 4.
Fives: The sum of all dice showing the number 5.
Sixes: The sum of all dice showing the number 6.

If a player manages to score at least 63 points (three of each number) in the upper section, he is awarded a bonus of 35 points.

Lower Section
-------------
Three of a Kind: Three dice showing the same number. Score: Sum of those three dice.
Four of a Kind: Four dice with the same number. Score: Sum of those four dice.
Small Straight: Any four consecutive numbers (1, 2, 3, 4; 2, 3, 4, 5; 3, 4, 5, 6). Score: 25 points.
Big Straight: A combination of either 1, 2, 3, 4, 5 or 2, 3, 4, 5, 6. Score: 30 points.
Full House: Any set of three combined with a set of two. Score: 40 points.
The Yacht: All five dice with the same number. Score: 50 points.
Chance: Any combination of dice. Score: Sum of all the dice.
