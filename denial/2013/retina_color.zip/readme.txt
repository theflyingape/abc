 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                         Retina Display Color                          | 
 |-----------------------------------------------------------------------|
 | ....................................... Extra Disk for Retina Display |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ..................................... Retina Display Color
 GROUP        : ...................................... Akronyme Analogiker
 COMPETITION  : ..................................................... None
 PARTY        : ..................................................... None
 PLATFORM     : .................................... NTSC VIC-20 + 32K RAM
 RELEASE DATE : ............................................... 09/03/2013
  
 SHORT
  DESCRIPTION : Color slideshow for ultra-hires interlace mode for the
                NTSC VIC-20: 192 x 416 = 79872 pixels

 CODE         : .................................................... Tokra
 SUPPORT:     : ..................................................... Mike

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ................................... NTSC VIC-20 + 32K RAM + uIEC/SD drive

 NOTE:
 
 ....................... Will *NOT* run on VICE (up to 2.4 at least, since
 .......................... interlace mode is not supported (yet) by VICE)

 INSTRUCTIONS:

 Two .d64-files are included. First one has the slideshow, the second one
 is an updated version of the tools-disk with the VIC-20 side of the
 .PPM-converter added.
 
 The converter is explained more thorougly in the techinfo.txt

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :

 GREETINGS TO:
 
 The members of the VIC-20 Denial-forum