
Name: Super Starship Space Attack
Author: Misfit
Released: 30.11.2014 (v1.0)
Requirements: 16k VIC-20 + Joystick. 
Description: Space shooter
Tested : VICE 2.4 (NTSC and PAL) and real VIC (PAL)

9 Levels + 2 Bonus levels

3 Game modes :
Child Mode (easy) (no bonus levels)
Gamer Mode (normal) (all levels)
I am Legend (hard) (all levels)

Find 3 power units and leave evil spaceship. Bottom of the level has an escape area. Every power unit raises your firepower.
Up / down = acceleration and brake
Left / right = move your spaceship
Fire = shoot

