A quick partycoded prod for the real wild compo of Assembly 2014.

Everything by Viznut while invading the capitalist zone of Assembly 2014.

Music recycled from our 2003 demo Kuutiomitta.
