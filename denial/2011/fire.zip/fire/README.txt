This is an implementation of the fire effect as in http://www.pouet.net/prod.php?which=6962.
(PAL only)

fire_pal.prg ... plain implementation for the unexpanded VIC-20
loader.prg ..... Version for the Vic-20 + 24K RAM inluding a scroller and digitized fire noise.

-- 
2011/11/19 A.M.
