 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                             Yes VIC can                               | 
 |-----------------------------------------------------------------------|
 | ....................Wild competition (VIC-20) entry for Revision 2011 |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ................................. ............ Yes VIC can
 GROUP        : ...................................... Akronyme Analogiker
 COMPETITION  : ..................................................... Wild
 PARTY        : .......................... Revision - The Easterparty 2011
 PLATFORM     : .............................PAL VIC-20 + at least 16K RAM
                        (extra RAM at BLK5 required for SJLOAD fastloader)
 RELEASE DATE : ............................................... 23/04/2011
  
 CODE         : .............................................. Tokra, Mike
 SUPPORT      : ...................................... Demoscene Passivist

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ..................................... PAL VIC-20 +32K RAM + uIEC/SD drive
  
 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 THANKS TO    : ..................................................... Mike
                                    (for his brilliant graphics converter)
                 
                ...................................... Demoscene Passivist
                                                     (for trying his best)
                                                        
 RESPECT TO:
 
 The VIC-20 elite
 
 GREETINGS TO:
 
 The members of the VIC-20 Denial-forum
 
 FUCKINGS TO:
 
 people who don't recognize VIC-20s with RAM expansions