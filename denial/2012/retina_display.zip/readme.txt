 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                            Retina Display                             | 
 |-----------------------------------------------------------------------|
 | .................. Wild competition (VIC-20) entry for Nordlicht 2012 |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ........................................... Retina Display
 GROUP        : ...................................... Akronyme Analogiker
 COMPETITION  : ..................................................... Wild
 PARTY        : ........................................... Nordlicht 2012
 PLATFORM     : .................................... NTSC VIC-20 + 32K RAM
 RELEASE DATE : ............................................... 20/07/2012
  
 SHORT
  DESCRIPTION : Slideshow for a new ultra-hires interlace mode for the
                NTSC VIC-20: 192 x 416 = 79872 pixels (25% more than C64)

 CODE         : .................................................... Tokra
 SUPPORT:     : ..................................................... Mike

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ................................... NTSC VIC-20 + 32K RAM + uIEC/SD drive

 NOTE:
 
 ....................... Will *NOT* run on VICE (up to 2.3 at least, since
 .......................... interlace mode is not supported (yet) by VICE)

 INSTRUCTIONS:

 Three .d64-files are included. Each has a "BOOT"-program that loads the
 viewer or presents a menu to choose the .PGM-converter or Mandelbrot-
 programs. In the viewer press SPACE afer each picture has been displayed.
 
 The converter and Mandelbrot-programs are explained more thorougly in the
 techinfo.txt

 Source to the mode itself is included.

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :

 GREETINGS TO:
 
 The members of the VIC-20 Denial-forum