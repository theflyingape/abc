/*
 *  mifli_quant.c
 *
 *  written 2012-02-16 by Michael Kircher
 *
 *  quantize a 84x384 *.ppm image to VIC-20 NTSC MIFLI
 *  (multi-colour 4x8 foreground attribute cells,
 *   3 global colours each raster, interlace)
 *
 *       Date of change: 2012-02-18  Michael Kircher
 *  - fine-tune 'mixed' foreground colours
 *
 *       Date of change: 2012-03-01  Michael Kircher
 *  - added *.bin output files for VIC-20
 *
 *  Date of last change: 2012-03-17  Michael Kircher
 *  - test for gamma-corrected output
 */

#include <stdio.h>
#include <stdlib.h>
#include "image.h"

#define R_WEIGHT 299
#define G_WEIGHT 587
#define B_WEIGHT 114

#define X_SIZE 84
#define Y_SIZE 384

#define DITHER

typedef enum {false,true} boolean;

typedef struct {int r,g,b;} ERROR;

typedef struct
{
  BYTE bitmap[X_SIZE/4];
  BYTE bck;
  BYTE brd;
  BYTE aux;
} VIC_LINE;

RGB vic_palette[16]=
{
  {  0,   0,   0},  /* Black        */
  {255, 255, 255},  /* White        */
  {182,  31,  33},  /* Red          */
  { 77, 240, 255},  /* Cyan         */
  {180,  63, 255},  /* Purple       */
  { 68, 226,  55},  /* Green        */
  { 26,  52, 255},  /* Blue         */
  {220, 215,  27},  /* Yellow       */
  {202,  84,   0},  /* Orange       */
  {233, 176, 114},  /* Light Orange */
  {231, 146, 147},  /* Light Red    */
  {154, 247, 253},  /* Light Cyan   */
  {224, 159, 255},  /* Light Purple */
  {143, 228, 147},  /* Light Green  */
  {130, 144, 255},  /* Light Blue   */
  {229, 222, 133}   /* Light Yellow */
};

/* gamma-corrected version of vic_palette[] */
RGB vic_palette_2[16];

boolean mix[8][8]=
{
  { true,false, true,false,false,false, true,false},
  {false, true,false, true,false,false,false, true},
  {false,false, true,false,false,false,false,false},
  {false,false,false, true,false, true,false, true},
  {false,false,false,false, true,false, true,false},
  {false,false,false,false,false, true,false, true},
  {false,false,false,false,false,false, true,false},
  {false,false,false,false,false,false,false, true}
};

int saturate_add(int base, int offset)
{
  int result=base+offset;
  if(result<0)   result=0;
  if(result>255) result=255;
  return(result);
}

double rgb_dist(RGB col1, RGB col2)
{
  double dr=(int)col1.r-(int)col2.r;
  double dg=(int)col1.g-(int)col2.g;
  double db=(int)col1.b-(int)col2.b;
  return(R_WEIGHT*dr*dr + G_WEIGHT*dg*dg + B_WEIGHT*db*db);
}

BYTE gamma(BYTE value)
{
  return((BYTE)((1.0*value)*(1.0*value)/255.0+0.5));
}

/* For each attribute cell, assign the colour with the least weighted squared distance as foreground. */
void quant_fore(BYTE fore[2][X_SIZE/4][Y_SIZE/16], IMAGE *src)
{
  SIZE f,x,x2,y,y2;
  double min_dist,try_dist;
  BYTE min_fore[2],try_fore[2];
  for(x=0; x<X_SIZE; x+=4)
    for(y=0; y<Y_SIZE; y+=16)
    {
      min_dist=256.0*256.0*(R_WEIGHT+G_WEIGHT+B_WEIGHT)*64;
      min_fore[0]=min_fore[1]=-1;
      for(try_fore[0]=0; try_fore[0]<8; try_fore[0]++)
        for(try_fore[1]=0; try_fore[1]<8; try_fore[1]++)
        {
          if(!mix[try_fore[0]][try_fore[1]]) continue;
          try_dist=0.0;
          for(f=0; f<2; f++)
            for(x2=0; x2<4; x2++)
              for(y2=f; y2<16; y2+=2)
                try_dist+=rgb_dist(image_rgb(((int)vic_palette_2[try_fore[0]].r+(int)vic_palette_2[try_fore[1]].r)/2,
                                             ((int)vic_palette_2[try_fore[0]].g+(int)vic_palette_2[try_fore[1]].g)/2,
                                             ((int)vic_palette_2[try_fore[0]].b+(int)vic_palette_2[try_fore[1]].b)/2),rgb_pixel(src,x+x2,y+y2));
          if(min_dist > try_dist)
          {
            min_dist = try_dist;
            min_fore[0] = try_fore[0];
            min_fore[1] = try_fore[1];
          }
        }
        fore[0][x>>2][y>>4]=min_fore[0];
        fore[1][x>>2][y>>4]=min_fore[1];
    }
}

/* Dither a line to the available colours, taking the different foreground of each cell into account. */
double quant_line(VIC_LINE *screen, IMAGE *dst,
                  BYTE fore[2][X_SIZE/4][Y_SIZE/16], IMAGE *src,
                  SIZE y,
                  ERROR *error2_curr, ERROR *error2_next, boolean trial,
                  int brd, int bck, int aux)
{
  double result=0.0;
  ERROR error_curr[X_SIZE+2],error_next[X_SIZE+2];
  int logical[4];
  RGB colour;
  double try_dist,min_dist;
  int try_index,min_index;
  int x,x0,x1,dx;
  int dr,dg,db;

  for(x=0; x<X_SIZE+2; x++)
  {
    error_curr[x]=error2_curr[x];
    error_next[x]=error2_next[x];
  }

  logical[0]=bck;
  logical[1]=brd;
  logical[3]=aux;

  /* Scan consecutive lines in serpentine fashion. */
  if(0 == (y&1)) {x0=0;x1=X_SIZE;dx=1;} else {x0=X_SIZE-1;x1=-1;dx=-1;}

  for(x=x0; x!=x1; x+=dx)
  {
    logical[2]=fore[y&1][x>>2][y>>4];
    colour=image_rgb(saturate_add(rgb_pixel(src,x,y).r,(error_curr[x+1].r+8)>>4),
                     saturate_add(rgb_pixel(src,x,y).g,(error_curr[x+1].g+8)>>4),
                     saturate_add(rgb_pixel(src,x,y).b,(error_curr[x+1].b+8)>>4));
    min_dist=256.0*256.0*(R_WEIGHT+G_WEIGHT+B_WEIGHT);
    min_index=-1;
    for(try_index=0; try_index<4; try_index++)
    {
      try_dist=rgb_dist(colour,vic_palette_2[logical[try_index]]);
      if(min_dist > try_dist)
      {
        min_dist  = try_dist;
        min_index = try_index;
      }
    }
    rgb_pixel(dst, x<<1   ,y)=vic_palette[logical[min_index]];
    rgb_pixel(dst,(x<<1)+1,y)=vic_palette[logical[min_index]];
    if(!trial) screen[y].bitmap[x>>2] |= min_index << (6-2*(x&3)); /* fan out bitmap data */
    result += min_dist;

#ifdef DITHER
    /* apply Floyd-Steinberg dither-matrix */
    dr=saturate_add(rgb_pixel(src,x,y).r,(error_curr[x+1].r+8)>>4)-(int)vic_palette_2[logical[min_index]].r;
    dg=saturate_add(rgb_pixel(src,x,y).g,(error_curr[x+1].g+8)>>4)-(int)vic_palette_2[logical[min_index]].g;
    db=saturate_add(rgb_pixel(src,x,y).b,(error_curr[x+1].b+8)>>4)-(int)vic_palette_2[logical[min_index]].b;

    error_curr[x+1+dx].r += 7*dr;
    error_curr[x+1+dx].g += 7*dg;
    error_curr[x+1+dx].b += 7*db;

    error_next[x+1+dx].r +=   dr;
    error_next[x+1+dx].g +=   dg;
    error_next[x+1+dx].b +=   db;

    error_next[x+1   ].r += 5*dr;
    error_next[x+1   ].g += 5*dg;
    error_next[x+1   ].b += 5*db;

    error_next[x+1-dx].r += 3*dr;
    error_next[x+1-dx].g += 3*dg;
    error_next[x+1-dx].b += 3*db;
#endif

  }

  if(!trial)
    for(x=0; x<X_SIZE+2; x++)
    {
      error2_curr[x]=error_curr[x];
      error2_next[x]=error_next[x];
    }

  return(result);
}

int main(int argc, char *argv[])
{
  IMAGE *src,*dst;
  FILE *stream;
  VIC_LINE *screen;
  BYTE fore[2][X_SIZE/4][Y_SIZE/16];
  ERROR error_curr[X_SIZE+2],error_next[X_SIZE+2];
  SIZE f,i,x,y;
  double try_dist,min_dist;
  int min_brd,min_bck,min_aux;
  int try_brd,try_bck,try_aux;
  
  if(      NULL == (src=image_load("input"))
     ||  X_SIZE != src->cols
     ||  Y_SIZE != src->rows
     || RGB_IMG != src->type
     ||    NULL == (dst=image_alloc(2*X_SIZE+32,Y_SIZE,RGB_IMG))
     ||    NULL == (screen=(VIC_LINE *)malloc(Y_SIZE*sizeof(VIC_LINE)))) exit(EXIT_FAILURE);

  /* apply gamma-correction (gamma = 2.0) to *both* palette and input image: */
  for(y=0; y<Y_SIZE; y++)
    for(x=0; x<X_SIZE; x++)
    {
      rgb_pixel(src,x,y).r=gamma(rgb_pixel(src,x,y).r);
      rgb_pixel(src,x,y).g=gamma(rgb_pixel(src,x,y).g);
      rgb_pixel(src,x,y).b=gamma(rgb_pixel(src,x,y).b);
    }

  for(i=0; i<16; i++)
  {
    vic_palette_2[i].r=gamma(vic_palette[i].r);
    vic_palette_2[i].g=gamma(vic_palette[i].g);
    vic_palette_2[i].b=gamma(vic_palette[i].b);
  }

  for(x=0; x<X_SIZE+2; x++)
  {
    error_curr[x].r=error_curr[x].g=error_curr[x].b=0;
    error_next[x].r=error_next[x].g=error_next[x].b=0;
  }

  quant_fore(fore,src);

  for(y=0; y<Y_SIZE; y++) for(x=0; x<X_SIZE/4; x++) screen[y].bitmap[x]=0;

  for(y=0; y<Y_SIZE; y++)
  {
    fprintf(stderr,"Line %d ...\n",y);
    min_dist=256.0*256.0*(R_WEIGHT+G_WEIGHT+B_WEIGHT)*X_SIZE;
    min_brd=min_bck=min_aux=-1;
    for(try_brd=0; try_brd<8; try_brd++)
      for(try_bck=try_brd+1; try_bck<16; try_bck++)
        for(try_aux=try_bck+1; try_aux<16; try_aux++)
        {
          try_dist=quant_line(screen,dst,fore,src,y,error_curr,error_next,true,try_brd,try_bck,try_aux);
          if(min_dist > try_dist)
          {
            min_dist = try_dist;
            min_brd  = try_brd;
            min_bck  = try_bck;
            min_aux  = try_aux;
          }
        }
    quant_line(screen,dst,fore,src,y,error_curr,error_next,false,min_brd,min_bck,min_aux);

    /* fan out the background, "border", and auxiliary colours for each raster line */
    screen[y].bck = min_bck;
    screen[y].brd = min_brd;
    screen[y].aux = min_aux;

    for(x=0; x<8; x++)
    {
      rgb_pixel(dst,2*X_SIZE   +x,y)=image_rgb(0,0,0);
      rgb_pixel(dst,2*X_SIZE+ 8+x,y)=vic_palette[min_bck];
      rgb_pixel(dst,2*X_SIZE+16+x,y)=vic_palette[min_brd];
      rgb_pixel(dst,2*X_SIZE+24+x,y)=vic_palette[min_aux];
    }

#ifdef DITHER
    for(x=0; x<X_SIZE+2; x++)
    { 
      error_curr[x]=error_next[x];
      error_next[x].r=error_next[x].g=error_next[x].b=0;
    }
#endif

  }

  image_save(dst,"result");

  for(f=0; f<2; f++)
    for(y=f; y<Y_SIZE; y+=2)
      for(x=0; x<X_SIZE; x++)
        rgb_pixel(dst,2*x,y)=rgb_pixel(dst,2*x+1,y)=vic_palette[fore[f][x>>2][y>>4]];
  image_save(dst,"result2");

  /* write out VIC data: */
  stream=fopen("bitmap.bin","wb");
  for(y=0; y<Y_SIZE; y++)
    for(x=0; x<X_SIZE/4; x++)
      fputc(screen[y].bitmap[x],stream);
  fclose(stream);

  stream=fopen("colour_top.bin","wb");
  for(y=0; y<Y_SIZE/16; y++)
    for(x=0; x<X_SIZE/4; x++)
      fputc(fore[0][x][y],stream);
  fclose(stream);

  stream=fopen("colour_bot.bin","wb");
  for(y=0; y<Y_SIZE/16; y++)
    for(x=0; x<X_SIZE/4; x++)
      fputc(fore[1][x][y],stream);
  fclose(stream);

  stream=fopen("900e.bin","wb");
  for(y=0; y<Y_SIZE; y++)
    fputc(screen[y].aux*16,stream);
  fclose(stream);

  stream=fopen("900f.bin","wb");
  for(y=0; y<Y_SIZE; y++)
    fputc(screen[y].bck*16+8+screen[y].brd,stream);
  fclose(stream);
  
  image_free(dst);
  image_free(src);

  free(screen);

  exit(EXIT_SUCCESS);
}