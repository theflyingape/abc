 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                            VIC can again                              | 
 |-----------------------------------------------------------------------|
 | ..................... Off-party release (VIC-20) at the Revision 2012 |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ............................................ VIC can again
 GROUP        : ...................................... Akronyme Analogiker
 COMPETITION  : ..................................................... None
 PARTY        : .......................... Revision - The Easterparty 2012
 PLATFORM     : ........................... NTSC VIC-20 + at least 24K RAM
                         (extra RAM at BLK5 required for conversion tools)
 RELEASE DATE : ............................................... 07/04/2011
  
 CODE         : .............................................. Tokra, Mike
 MORAL SUPPORT: ...................................... Demoscene Passivist

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ................................... NTSC VIC-20 + 32K RAM + uIEC/SD drive

 NOTE:
 
 ....................... Will *NOT* run on VICE (up to 2.3 at least, since
 .......................... interlace mode is not supported (yet) by VICE)

 INSTRUCTIONS:

 Three .d64-files are included. Each has a "BOOT"-program that loads the
 viewer or converter. In the viewer press SPACE afer each picture has been
 displayed. The viewer ends rather unceremoniously after 7 pictures.
 Side A has hires pictures, while side B has multicolor pics. The last
 .d64 hold the two converters which are explained more thorougly in the
 techinfo.txt

 Sources to the mode itself as well as for Mike's converters is included.

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 THANKS TO    : ..................................................... Mike
                              (AGAIN for his brilliant graphics converters)
 
 GREETINGS TO:
 
 The members of the VIC-20 Denial-forum